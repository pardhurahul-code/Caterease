import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { Toaster } from 'sonner';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider, useAuth, type UserRole } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { ForgotPasswordPage, LoginPage, RegisterPage, ResetPasswordPage } from './pages/AuthPages';
import { VerifyQrPage } from './pages/VerifyQrPage';

const MenuPage = lazy(() => import('./pages/MenuPage').then((m) => ({ default: m.MenuPage })));
const PackagesPage = lazy(() => import('./pages/PackagesPage').then((m) => ({ default: m.PackagesPage })));
const AiSuitePage = lazy(() => import('./pages/AiSuitePage').then((m) => ({ default: m.AiSuitePage })));
const CheckoutPage = lazy(() => import('./pages/CheckoutPage').then((m) => ({ default: m.CheckoutPage })));
const CustomerDashboard = lazy(() =>
  import('./dashboards/customer/CustomerDashboard').then((m) => ({ default: m.CustomerDashboard }))
);
const AdminDashboard = lazy(() =>
  import('./dashboards/admin/AdminDashboard').then((m) => ({ default: m.AdminDashboard }))
);
const StaffDashboard = lazy(() =>
  import('./dashboards/staff/StaffDashboard').then((m) => ({ default: m.StaffDashboard }))
);

function RouteSkeleton() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-16">
      <div className="h-48 rounded-2xl bg-stone-200/70 dark:bg-stone-800/70 animate-pulse" />
    </div>
  );
}

function roleHome(role: UserRole) {
  if (role === 'ADMIN') return '/dashboard/admin';
  if (role === 'STAFF') return '/dashboard/staff';
  return '/dashboard/customer';
}

function ProtectedRoute({
  allowedRoles,
  children,
}: {
  allowedRoles: UserRole[];
  children: React.ReactNode;
}) {
  const { user, loading } = useAuth();

  if (loading) {
    return <RouteSkeleton />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(user.role)) {
    return <Navigate to={roleHome(user.role)} replace />;
  }

  return <>{children}</>;
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CartProvider>
          <BrowserRouter>
            <div className="min-h-screen flex flex-col bg-[#FAF9F6] dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors">
              <Toaster richColors position="bottom-right" />
              <Navbar />
              <div className="flex-1">
                <Suspense fallback={<RouteSkeleton />}>
                  <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/menu" element={<MenuPage />} />
                    <Route path="/packages" element={<PackagesPage />} />
                    <Route path="/ai" element={<AiSuitePage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                    <Route path="/reset-password" element={<ResetPasswordPage />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                    <Route path="/verify/:token" element={<VerifyQrPage />} />

                    <Route
                      path="/dashboard/customer"
                      element={
                        <ProtectedRoute allowedRoles={['CUSTOMER']}>
                          <CustomerDashboard />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/dashboard/customer/bookings/:bookingId"
                      element={
                        <ProtectedRoute allowedRoles={['CUSTOMER']}>
                          <CustomerDashboard initialTab="bookings" />
                        </ProtectedRoute>
                      }
                    />
                    <Route
                      path="/dashboard/customer/*"
                      element={
                        <ProtectedRoute allowedRoles={['CUSTOMER']}>
                          <CustomerDashboard />
                        </ProtectedRoute>
                      }
                    />

                    <Route
                      path="/dashboard/admin/*"
                      element={
                        <ProtectedRoute allowedRoles={['ADMIN']}>
                          <AdminDashboard />
                        </ProtectedRoute>
                      }
                    />

                    <Route
                      path="/dashboard/staff/*"
                      element={
                        <ProtectedRoute allowedRoles={['STAFF']}>
                          <StaffDashboard />
                        </ProtectedRoute>
                      }
                    />

                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </Suspense>
              </div>
              <Footer />
            </div>
          </BrowserRouter>
        </CartProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
